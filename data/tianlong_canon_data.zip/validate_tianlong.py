#!/usr/bin/env python3
"""Check the supplied Tianlong JSON contract and replay canonical state changes.

Usage: python3 validate_tianlong.py --data data --report data/12_validation.json
No third-party dependencies. This checks structure and model consistency, not
literary exhaustiveness, historical chronology, or the truth of inferred fields.
"""
import argparse, collections, copy, json, pathlib, re, sys

FILES={'persons':'04_persons.json','locations':'01_locations.json','factions':'03_factions.json','items':'05_items.json','skills':'06_skills.json','events':'08_canon.json'}
STATUS={'alive','wounded','dead'}
SET_KEYS={'status','location','title','faction','power','hidden','state','holder'}
OPS={'set','add','push','pull','link','unlink','reveal'}
TYPE={'内功','外功','掌法','指法','剑法','刀法','棍棒','暗器','轻功','阵法','毒术','医术','奇术'}
TIER={'不会武功','三流','二流','一流','绝顶'}
KINDS={'兵刃','秘籍','药物','毒物','信物','宝物','杂物'}
ANCHORS={'段誉':5,'王语嫣':5,'钟灵':15,'阿朱':15,'左子穆':40,'钟万仇':45,'游骥':50,'段正淳':60,'南海鳄神':70,'慕容复':80,'玄慈':85,'鸠摩智':90,'段延庆':92,'乔峰':95,'萧远山':95,'天山童姥':95,'无崖子':99,'扫地老僧':100}
CN={'一':1,'二':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9,'十':10,'十一':11,'十二':12,'元':1}
def game_month(text):
    m=re.search(r'(元祐|绍圣|元符)([元一二三四五六七八九十]+)年([一二三四五六七八九十]+)月',text)
    if not m:return None
    era,y,mo=m.groups();y=CN.get(y);mo=CN.get(mo)
    if not y or not mo:return None
    # Only convert the declared game estimate. This is not a historical lunar date.
    year={'元祐':1085,'绍圣':1093,'元符':1097}[era]+y
    return (year-1092)*360+(mo-1)*30

def validate(data_dir):
    errors=[];warnings=[]
    def err(code,context,detail):errors.append({'code':code,'context':context,'detail':detail})
    def warn(code,context,detail):warnings.append({'code':code,'context':context,'detail':detail})
    def read(name):
        p=data_dir/name
        try:return json.loads(p.read_text(encoding='utf-8'))
        except (OSError,UnicodeError,json.JSONDecodeError) as ex:err('JSON_READ',name,str(ex));return None
    index=read('00_index.json');meta=read('meta.json')
    tables={k:read(v) for k,v in FILES.items()};roads=read('02_roads.json');relations=read('07_relations.json')
    if not index or any(v is None for v in tables.values()) or roads is None or relations is None:
        return {'passed':False,'errors':errors,'warnings':warnings}
    ids={k:{x['id'] for x in index.get(k,[])} for k in FILES};all_ids=set().union(*ids.values());which={}
    for kind,rows in index.items():
        for row in rows:
            id=row['id']
            if id in which:err('DUPLICATE_ID',id,f'{which[id]} / {kind}')
            which[id]=kind
    for kind,rows in tables.items():
        if not isinstance(rows,list):err('ARRAY_REQUIRED',FILES[kind],'顶层必须为数组');continue
        seen=set()
        for r in rows:
            id=r.get('id')
            if id in seen:err('DUPLICATE_ROW',FILES[kind],id)
            seen.add(id)
            if id not in ids[kind]:err('UNREGISTERED_ENTITY',FILES[kind],id)
            if not re.fullmatch(r'第(?:[1-9]|[1-4][0-9]|50)回',r.get('src','')):err('SOURCE_REF',id,r.get('src'))
        if seen != ids[kind]:err('INDEX_TABLE_COVERAGE',kind,{'index_only':sorted(ids[kind]-seen),'table_only':sorted(seen-ids[kind])})
    def ref(value,kind,ctx,nullable=True):
        if value is None and nullable:return
        if value not in ids.get(kind,set()):err('BAD_REFERENCE',ctx,{'id':value,'expected':kind})
    def length(value,n,ctx):
        if value is not None and (not isinstance(value,str) or len(value)>n):err('TEXT_LENGTH',ctx,{'limit':n,'actual':len(value) if isinstance(value,str) else None})
    for r in tables['persons']:
        id=r['id'];ref(r.get('faction'),'factions',id+'.faction');ref(r.get('location'),'locations',id+'.location',False)
        if r.get('status') not in STATUS:err('STATUS_ENUM',id,r.get('status'))
        if not isinstance(r.get('power'),(int,float)) or not 0<=r['power']<=100:err('POWER_RANGE',id,r.get('power'))
        for s in r.get('skills',[]):ref(s,'skills',id+'.skills',False)
        for key,n in [('persona',60),('appearance',40),('speech',40),('agenda',30)]:length(r.get(key),n,id+'.'+key)
        if id in ANCHORS and r['power']!=ANCHORS[id]:err('POWER_ANCHOR',id,{'expected':ANCHORS[id],'actual':r['power']})
        if r.get('initial_state_confirmed') is False:warn('UNKNOWN_INITIAL_STATE',id,r.get('unknown_fields',[]))
    for r in tables['locations']:
        ref(r.get('parent'),'locations',r['id']+'.parent');length(r.get('desc'),60,r['id']+'.desc')
        if len(r.get('lore',[]))>5:err('LORE_COUNT',r['id'],len(r['lore']))
        for s in r.get('lore',[]):length(s,50,r['id']+'.lore')
    for r in tables['factions']:
        ref(r.get('base'),'locations',r['id']+'.base');ref(r.get('leader'),'persons',r['id']+'.leader');length(r.get('desc'),60,r['id']+'.desc')
    for r in tables['items']:
        id=r['id'];ref(r.get('location'),'locations',id+'.location');ref(r.get('holder'),'persons',id+'.holder')
        if r.get('location') is not None and r.get('holder') is not None:err('ITEM_DUAL_OWNER',id,'location与holder不能同时非空')
        if r.get('kind') not in KINDS:err('ITEM_KIND',id,r.get('kind'))
        for k,n in [('desc',60),('hint',50),('effect',40)]:length(r.get(k),n,id+'.'+k)
        if r.get('kind')=='秘籍' and r.get('grants') is None:err('BOOK_GRANTS',id,'秘籍缺少grants')
        if r.get('kind')!='秘籍' and r.get('grants') is not None:err('NONBOOK_GRANTS',id,r['grants'])
        for g in [r.get('grants')]+r.get('grants_extra',[]):
            if g:ref(g.get('skill'),'skills',id+'.grants');
    for r in tables['skills']:
        ref(r.get('school'),'factions',r['id']+'.school')
        if r.get('type') not in TYPE:err('SKILL_TYPE',r['id'],r.get('type'))
        if r.get('tier') not in TIER:err('SKILL_TIER',r['id'],r.get('tier'))
        length(r.get('desc'),60,r['id']+'.desc');length(r.get('requires'),40,r['id']+'.requires')
    graph={id:set() for id in ids['locations']};edge_set=set()
    for i,r in enumerate(roads):
        if not isinstance(r,list) or len(r)!=3:err('ROAD_SHAPE',str(i),r);continue
        a,b,d=r;ref(a,'locations','road '+str(i),False);ref(b,'locations','road '+str(i),False)
        if not isinstance(d,int) or isinstance(d,bool) or d<0:err('ROAD_DAYS',str(i),d)
        edge=tuple(sorted([a,b]));
        if edge in edge_set:err('DUPLICATE_ROAD',str(i),r)
        if a==b:err('ROAD_SELF',str(i),r)
        edge_set.add(edge)
        if a in graph and b in graph:graph[a].add(b);graph[b].add(a)
    comps=[];remaining=set(graph)
    while remaining:
        root=min(remaining);q=[root];comp=set()
        while q:
            a=q.pop()
            if a in comp:continue
            comp.add(a);q.extend(graph[a]-comp)
        remaining-=comp;comps.append(sorted(comp))
    if len(comps)!=1:err('ROAD_DISCONNECTED','02_roads.json',sorted(comps,key=len))
    for r in tables['locations']:
        if r.get('parent') and tuple(sorted([r['id'],r['parent']])) not in edge_set:err('PARENT_ROAD',r['id'],r['parent'])
    events=tables['events'];event_map={x['id']:x for x in events}
    for r in relations:
        ref(r['src'],which.get(r['src'],''),'07.src',False);ref(r['dst'],which.get(r['dst'],''),'07.dst',False)
        length(r.get('rel'),8,'07.rel')
        if not re.fullmatch(r'第(?:[1-9]|[1-4][0-9]|50)回',r.get('src_ref','')):err('REL_SOURCE','07',r)
        if r.get('secret'):
            target=r.get('revealed_by')
            if target:
                if target not in event_map:err('SECRET_EVENT',str((r['src'],r['dst'],r['rel'])),target)
                elif not any(x.get('op')=='reveal' and (x.get('src'),x.get('dst'),x.get('rel'))==(r['src'],r['dst'],r['rel']) for x in event_map[target]['effects']):err('SECRET_MISSING_REVEAL',target,r)
            elif not r.get('unrevealed_reason'):err('SECRET_NO_EXPLANATION','07',r)
    orders=[x['order'] for x in events]
    if orders!=list(range(1,len(events)+1)):err('ORDER_SEQUENCE','08',orders)
    state={r['id']:copy.deepcopy(r) for kind,rows in tables.items() if kind!='events' for r in rows}
    rel_state={(r['src'],r['dst'],r['rel']):copy.deepcopy(r) for r in relations}
    first_acquired={};first_moved={};replay_steps=0;previous_day=None
    for e in events:
        ctx=e['id'];day=game_month(e.get('when',''))
        if day is None:warn('DATE_UNPARSED',ctx,e.get('when'))
        elif previous_day is not None and day<previous_day:err('DATE_ORDER',ctx,{'day':day,'previous_day':previous_day})
        if day is not None:previous_day=day
        ref(e['where'],'locations',ctx+'.where',False);length(e.get('summary'),60,ctx+'.summary')
        if e.get('weight') not in (1,2):err('EVENT_WEIGHT',ctx,e.get('weight'))
        for a in e.get('actors',[]):ref(a,'persons',ctx+'.actors',False)
        if len(e.get('requires',[]))>3:err('REQUIRES_COUNT',ctx,len(e['requires']))
        for req in e.get('requires',[]):
            if not isinstance(req,list) or len(req)!=3:err('REQUIRES_SHAPE',ctx,req);continue
            id,key,expected=req
            if id not in state:err('REQUIRES_ENTITY',ctx,id);continue
            actual=state[id].get(key)
            holds=expected in actual if key=='skills' and isinstance(actual,list) else actual==expected
            if not holds:err('REQUIRES_FAIL',ctx,{'id':id,'key':key,'expected':expected,'actual':actual})
        for z in e['effects']:
            op=z.get('op')
            if op not in OPS:err('EFFECT_OP',ctx,z);continue
            if op in ('set','add','push','pull'):
                id=z.get('id');key=z.get('key');value=z.get('value')
                if id not in state:err('EFFECT_ENTITY',ctx,id);continue
                r=state[id];kind=which.get(id)
                if op=='set':
                    if key not in SET_KEYS:err('SET_KEY',ctx,z)
                    if key=='status':
                        if kind!='persons' or value not in STATUS:err('SET_STATUS',ctx,z)
                        if r.get('status')=='dead' and value!='dead':err('RESURRECTION',ctx,id)
                    if key=='power' and (kind!='persons' or not isinstance(value,(int,float)) or not 0<=value<=100):err('SET_POWER',ctx,z)
                    if key=='location':ref(value,'locations',ctx+'.effects.location');first_moved.setdefault(id,(ctx,value))
                    if key=='faction':ref(value,'factions',ctx+'.effects.faction')
                    if key=='holder':ref(value,'persons',ctx+'.effects.holder')
                    if key=='state' and isinstance(value,dict):
                        for k in ('leader','ruler','eye_donor'):
                            if k in value:ref(value[k],'persons',ctx+'.state.'+k)
                        if 'subordinate_to' in value:ref(value['subordinate_to'],'factions',ctx+'.state.subordinate_to')
                    r[key]=copy.deepcopy(value)
                elif op=='add':
                    if key!='power' or kind!='persons':err('ADD_KEY',ctx,z)
                    r[key]=r.get(key,0)+value
                    if not 0<=r[key]<=100:err('ADD_POWER_RANGE',ctx,{'id':id,'value':r[key]})
                else:
                    if key!='skills' or kind!='persons':err('SKILL_EFFECT_KEY',ctx,z)
                    ref(value,'skills',ctx+'.effects.skills',False)
                    if op=='push':
                        if value in r.get('skills',[]):warn('SKILL_ALREADY_PRESENT',ctx,{'id':id,'skill':value})
                        else:r.setdefault('skills',[]).append(value)
                        first_acquired.setdefault((id,value),ctx)
                    else:
                        if value not in r.get('skills',[]):err('PULL_MISSING_SKILL',ctx,z)
                        else:r['skills'].remove(value)
            else:
                pair=(z.get('src'),z.get('dst'),z.get('rel'))
                for id in pair[:2]:
                    if id not in all_ids:err('LINK_ENTITY',ctx,id)
                length(pair[2],8,ctx+'.effects.rel')
                if op=='link':rel_state[pair]=copy.deepcopy(z)
                elif op=='unlink':
                    if pair not in rel_state:err('UNLINK_MISSING',ctx,pair)
                    else:del rel_state[pair]
                elif op=='reveal':
                    if pair not in rel_state:err('REVEAL_MISSING_RELATION',ctx,pair)
                    elif not rel_state[pair].get('secret'):err('REVEAL_NONSECRET',ctx,pair)
                    else:rel_state[pair]['secret']=False
        for id in ids['items']:
            r=state[id]
            if r.get('holder') is not None and r.get('location') is not None:err('REPLAY_ITEM_DUAL_OWNER',ctx,id)
        replay_steps+=1
    # A meaningful contamination check: skills acquired in events must not already
    # appear in that character's opening snapshot.
    for p in tables['persons']:
        for s in p.get('skills',[]):
            if (p['id'],s) in first_acquired:err('INITIAL_FUTURE_SKILL',p['id'],{'skill':s,'first_push':first_acquired[(p['id'],s)]})
    late=[(p,s) for p,s in [('段誉','北冥神功'),('段誉','六脉神剑'),('虚竹','小无相功'),('虚竹','天山六阳掌'),('游坦之','神足经'),('鸠摩智','小无相功'),('乔峰','降龙十八掌')] if s in state[p].get('skills',[])]
    return {'passed':not errors,'scope':'结构、引用、长度、道路、锚点、隐情映射、顺序与requires回放；不证明原著事实穷尽或所有推断正确。',
      'counts':{**{k:len(v) for k,v in tables.items()},'roads':len(roads),'relations':len(relations)},
      'checks':{'global_id_unique':not any(x['code']=='DUPLICATE_ID' for x in errors),'road_components':len(comps),'replayed_events':replay_steps,'requires_failures':sum(x['code']=='REQUIRES_FAIL' for x in errors),'anchor_count':len(ANCHORS),'late_skill_checks':len(late),'error_count':len(errors),'warning_count':len(warnings)},
      'errors':errors,'warnings':warnings,'limitations':['日期是抽取者推断；转成游戏日数不增加其史实可信度。','没有用户实际导入校验器，未检验该外部程序。','来源excerpt为定位证据，未逐字段证明文学事实。','initial_state_confirmed=false的枚举占位必须禁用自动开端活动。']}

def main():
    p=argparse.ArgumentParser();p.add_argument('--data',type=pathlib.Path,default=pathlib.Path(__file__).parent/'data');p.add_argument('--report',type=pathlib.Path);args=p.parse_args()
    result=validate(args.data);s=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
    if args.report:args.report.write_text(s,encoding='utf-8')
    print(s);return 0 if result['passed'] else 1
if __name__=='__main__':sys.exit(main())
